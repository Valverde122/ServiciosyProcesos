import java.io.File;
import java.io.IOException;

public class Lanzador {
    public static void main(String[] args) throws IOException {
        ProcessBuilder p1=new ProcessBuilder("java","Main","Pedro","Jesus","Lucia","perico");
        ProcessBuilder p2=new ProcessBuilder("java","Main","Jorge","Victor","Sebas","Ivan");
        p1.redirectOutput(new File("examen1.txt"));
        p2.redirectOutput(new File("examen2.txt"));

        p1.start();
        p2.start();
        System.out.println("Los procesos han sido lanzados con éxito");

    }
}
