import java.time.LocalDateTime;

public class Examinador implements Runnable {
    private Thread hilo;
    BufferExamenes buffer;

    public Thread getHilo() {
        return hilo;
    }

    public Examinador(String alumno, BufferExamenes generador) {
        // Construye el hilo. El nombre será el nombre del alumno.
        hilo=new Thread(this, alumno);

        // Establece el valor de la propiedad buffer

        hilo.setPriority(1);
        this.buffer=generador;
        // Inicia el hilo.
        hilo.start();
    }

    @Override
    public void run() {
        String codigoExamen = null;
        try {
            codigoExamen = this.buffer.consumirExamen();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        if (codigoExamen != null) {
            // Simula aquí un examen de 10 preguntas
            // cuyas respuestas se seleccionarán al azar
            // entre A, B, C, D o – (sin contestar).
            int yr= LocalDateTime.now().getYear();
            int nuemeroExamen=0;
            String codigo="E"+nuemeroExamen+";" +yr+";"+this.hilo.getName();
            String respuestas[]={"A", "B", "C", "D", "Sin contestar"};

            for (int i=0; i<10; i++){
                int numero=(int)(Math.random()*5);
                System.out.println(codigo+" Pregunta -->" +i+ " Respuesta--> "+ respuestas[numero]);
            }

        }
        else {
            System.out.println("Agotado tiempo de espera y " +
                    "no hay más exámenes");
        }
    }
}

